import os
import re
import math
from typing import List, Set, Dict
from PyPDF2 import PdfReader
from docx import Document
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
import streamlit as st


class TextPreprocessor:
    """Handles all text preprocessing operations including stemming, tokenization, and stopword removal."""

    def __init__(self, stopwords: Set[str] = None):
        self.stemmer = StemmerFactory().create_stemmer()
        self.stopwords = stopwords or {"dan", "di", "ke", "dari", "yang", "untuk", "pada"}

    def preprocess(self, text: str) -> List[str]:
        text = text.lower()
        tokens = re.findall(r'\b\w+\b', text)
        tokens = [word for word in tokens if word not in self.stopwords]
        return [self.stemmer.stem(word) for word in tokens]

    def count_words(self, tokens: List[str]) -> Dict[str, int]:
        word_counts = {}
        for token in tokens:
            word_counts[token] = word_counts.get(token, 0) + 1
        return word_counts


class DocumentReader:
    @staticmethod
    def read_file(filepath: str, encodings: List[str] = None) -> str:
        ext = os.path.splitext(filepath)[1].lower()

        if ext == '.txt':
            encodings = encodings or ['utf-8', 'latin-1', 'iso-8859-1']
            for encoding in encodings:
                try:
                    with open(filepath, 'r', encoding=encoding) as f:
                        return f.read()
                except UnicodeDecodeError:
                    continue
            raise UnicodeDecodeError(f"Unable to decode the file: {filepath}")

        elif ext == '.pdf':
            reader = PdfReader(filepath)
            return " ".join(page.extract_text() for page in reader.pages if page.extract_text())

        elif ext == '.docx':
            doc = Document(filepath)
            return " ".join(paragraph.text for paragraph in doc.paragraphs)

        else:
            raise ValueError(f"Unsupported file format: {ext}")

    @staticmethod
    def list_files(directory: str, extensions: List[str] = None) -> List[str]:
        extensions = extensions or [".txt", ".pdf", ".docx"]
        return [
            os.path.join(directory, f)
            for f in os.listdir(directory)
            if os.path.splitext(f)[1].lower() in extensions
        ]


class BM25Scorer:
    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b = b
        self.preprocessor = TextPreprocessor()

    def compute_scores(self, query: str, docs: List[List[str]]) -> List[float]:
        avg_doc_length = sum(len(doc) for doc in docs) / len(docs)
        N = len(docs)
        query_terms = self.preprocessor.preprocess(query)
        scores = []

        for doc in docs:
            doc_length = len(doc)
            score = 0
            for term in query_terms:
                f = doc.count(term)
                if f == 0:
                    continue
                df = sum(1 for d in docs if term in d)
                idf = math.log((N - df + 0.5) / (df + 0.5) + 1)
                tf = (f * (self.k1 + 1)) / (f + self.k1 * (1 - self.b + self.b * (doc_length / avg_doc_length)))
                score += idf * tf
            scores.append(score)
        return scores


def main():
    st.title("Document Similarity Checker with BM25")
    st.sidebar.title("Options")
    
    # Sidebar inputs
    directory = st.sidebar.text_input("Directory Path", value="")
    query = st.sidebar.text_input("Search Query", value="")
    start_process = st.sidebar.button("Start Processing")

    if start_process:
        if not os.path.isdir(directory):
            st.error("Invalid directory path. Please enter a valid path.")
            return

        # Initialize components
        doc_reader = DocumentReader()
        preprocessor = TextPreprocessor()
        bm25_scorer = BM25Scorer()

        # List files and preprocess documents
        files = doc_reader.list_files(directory)
        if not files:
            st.error("No files found in the specified directory.")
            return

        st.write("### Files Found:")
        for file in files:
            st.write(f"- {file}")

        docs = []
        word_counts_per_doc = []
        for file in files:
            try:
                content = doc_reader.read_file(file)
                tokens = preprocessor.preprocess(content)
                docs.append(tokens)
                word_counts_per_doc.append(preprocessor.count_words(tokens))
            except Exception as e:
                st.warning(f"Error reading file {file}: {e}")

        if not docs:
            st.error("No documents successfully processed.")
            return

        # Display stemming results and word counts
        st.write("### Word Counts After Preprocessing:")
        for i, word_counts in enumerate(word_counts_per_doc, 1):
            st.write(f"**Document {i} ({files[i-1]}):**")
            st.write(word_counts)

        # Calculate BM25 scores
        scores = bm25_scorer.compute_scores(query, docs)

        # Display results
        st.write("### BM25 Scores:")
        for i, score in enumerate(scores, 1):
            st.write(f"Document {i}: **{files[i-1]}** - Score: **{score:.4f}**")


if __name__ == "__main__":
    main()
